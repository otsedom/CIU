function setup() {
  createCanvas(400, 400, WEBGL);
}

function draw() {
  background(220);

  translate(mouseX - width / 2, mouseY - height / 2);
  beginShape();
  noFill();
  // Puntos de la forma
  vertex(-100, -100, -100);
  vertex(100, -100, -100);
  vertex(0, 0, 100);

  vertex(100, -100, -100);
  vertex(100, 100, -100);
  vertex(0, 0, 100);

  vertex(100, 100, -100);
  vertex(-100, 100, -100);
  vertex(0, 0, 100);

  vertex(-100, 100, -100);
  vertex(-100, -100, -100);
  vertex(0, 0, 100);
  endShape();
}