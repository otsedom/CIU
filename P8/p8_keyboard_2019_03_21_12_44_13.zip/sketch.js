function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
	if ( keyIsPressed ) {
		
		if (keyCode != UP_ARROW && keyCode != DOWN_ARROW){
			var x=keyCode;
			text(key+" ASCII "+ x , 20 , 20 ) ;
		}
		else{			
		if ( keyCode == UP_ARROW) text(key, 20 , 20 );
			else 
				text(key, 20 , 20 );
		}
	}
}