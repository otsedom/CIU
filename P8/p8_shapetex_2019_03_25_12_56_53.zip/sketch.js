var img;

function preload() {
  img=loadImage ('logoulpgc.png') ;
}

function setup() {
  createCanvas(400, 400, WEBGL);
  textureMode(NORMAL);
}

function draw() {
  background(0);

  translate(mouseX - width / 2, mouseY - height / 2);
  
  //Asigna textura
  texture(img);
  beginShape(TRIANGLES);
  // Vértices de la forma
  vertex(-100, -100, -100,0,0);
  vertex( 100, -100, -100,1,0);
  vertex(   0,    0,  100,1,1);
  
  vertex( 100, -100, -100,1,0);
  vertex( 100,  100, -100,0,0);
  vertex(   0,    0,  100,1,1);

  vertex( 100, 100, -100,0,0);
  vertex(-100, 100, -100,1,0);
  vertex(   0,   0,  100,1,1);

  vertex(-100,  100, -100,1,0);
  vertex(-100, -100, -100,0,0);
  vertex(   0,    0,  100,1,1);
  endShape();
}