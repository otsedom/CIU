var cirx=0;

function setup(){
	createCanvas(400,400);
	noStroke();
}

function draw(){
	background(0);
	
	var cirtam=50;
	
	if(random(10)>9){
		cirtam=60;
	}

	fill(193,255,62);
	ellipse(cirx,50,cirtam,cirtam);
	cirx=cirx+1;
	if(cirx>400){
		cirx=0;
	}	
}