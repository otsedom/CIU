var pos=0;
var mov=5;
var sonido;

function preload( ) {
	sonido = loadSound("Bass-Drum-1.wav");
}

function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(128);
  ellipse(pos,30,30,30);
  
  pos=pos+mov;
  
  if (pos>=400 || pos<=0){
    mov=-mov;
    sonido.play ( ) ; 
  }
}

