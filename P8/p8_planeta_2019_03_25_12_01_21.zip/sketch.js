var ang;
var angS;

function setup() {
  createCanvas(400, 400, WEBGL);
  stroke(0);
  
  //Inicializa
  ang=0;
  angS=0;
}

function draw() {
  background(200);
  
  //Esfera
  rotateX(radians(-45));
  
  //Planeta
  push();
  rotateY(radians(ang));
  sphere(100);
  pop();
  
  //Resetea tras giro completo
  ang=ang+0.25;
  if (ang>360)
    ang=0;
    
  //Objeto 
  push();
  rotateZ(radians(angS));
  translate(-width*0.3,0,0);
  box(10);
  pop();
  
   //Resetea tras giro completo
  angS=angS+0.25;
  if (angS>360)
    angS=0;
}