var Radio = 50;
var cuenta = 0;
function setup ( )
{
  createCanvas (400 ,400) ;
  background(0) ;
}

function draw( )
{
  background(0) ;
  stroke (175 ,90) ;
  fill (175 ,40) ;
  print(" Iteraciones : " + cuenta ) ;
  ellipse (20+cuenta , height /2 , Radio , Radio ) ;
  cuenta++;
}