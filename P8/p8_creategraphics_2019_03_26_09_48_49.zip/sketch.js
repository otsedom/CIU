var lienzo;

function setup() {
  createCanvas(400, 400,WEBGL);
  //Creamos lienzo
  graphics= createGraphics(100 ,100) ;
  graphics.background(255) ;
}

function draw() {
  background(220);
  
  //Añadims círculos de color aleatorio al segundo lienzo en base a la posición del ratón
  graphics.fill( random (0,255) , random (0,255) , random (0,255) ) ;
	graphics.ellipse (100*mouseX/width , 100*mouseY/height , 20 ) ;
  //Rotación del cubo
  rotateX(frameCount*0.03 ) ;
  rotateY(frameCount*0.03 ) ;
  rotateZ(frameCount*0.03 ) ;
  //Asignamos textura al cubo
  texture(graphics) ;
  box (100) ;
}