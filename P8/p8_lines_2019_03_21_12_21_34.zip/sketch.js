function setup() {
  createCanvas(400, 400);
	background(0);
}

function draw() {
  background(220);
	stroke(0,random(255),0);  
  line(mouseX, mouseY, random(width), random(height));
}