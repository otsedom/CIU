var dragX,dragY,moveX,moveY;

function setup() {
  createCanvas(400, 400);
  smooth();
  noStroke();
}

function draw() {
  background(220);
  fill(0);
  ellipse(dragX,dragY,30,30);
  fill(150);
  ellipse(moveX,moveY,30,30);
}

function mouseMoved ( ) {
  moveX=mouseX ;
  moveY=mouseY ;
  }

function mouseDragged ( ) { 
  dragX=mouseX ;
  dragY=mouseY ;
}